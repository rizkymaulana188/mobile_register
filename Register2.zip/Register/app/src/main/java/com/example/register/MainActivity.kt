package com.example.register


import android.os.Bundle
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {

    private lateinit var tilNama: TextInputLayout
    private lateinit var tilEmail: TextInputLayout
    private lateinit var tilPassword: TextInputLayout
    private lateinit var tilConfirm: TextInputLayout

    private lateinit var etNama: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var etConfirm: TextInputEditText

    private lateinit var rgGender: RadioGroup

    private lateinit var cbMusic: CheckBox
    private lateinit var cbSport: CheckBox
    private lateinit var cbGame: CheckBox
    private lateinit var cbReading: CheckBox

    private lateinit var spinnerCity: Spinner
    private lateinit var btnSubmit: Button

    private val cities = arrayOf("Jakarta", "Bandung", "Surabaya", "Yogyakarta")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initView()
        setupSpinner()
        setupValidation()
        setupSubmit()
        setupLongPress()
    }

    private fun initView() {
        tilNama = findViewById(R.id.tilNama)
        tilEmail = findViewById(R.id.tilEmail)
        tilPassword = findViewById(R.id.tilPassword)
        tilConfirm = findViewById(R.id.tilConfirmPassword)

        etNama = findViewById(R.id.etNama)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirm = findViewById(R.id.etConfirmPassword)

        rgGender = findViewById(R.id.rgGender)

        cbMusic = findViewById(R.id.cbMusic)
        cbSport = findViewById(R.id.cbSport)
        cbGame = findViewById(R.id.cbGame)
        cbReading = findViewById(R.id.cbReading)

        spinnerCity = findViewById(R.id.spinnerCity)
        btnSubmit = findViewById(R.id.btnSubmit)
    }

    private fun setupSpinner() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            cities
        )
        spinnerCity.adapter = adapter
    }

    private fun validateForm(): Boolean {

        val nama = etNama.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val pass = etPassword.text.toString()
        val confirm = etConfirm.text.toString()

        tilNama.error = null
        tilEmail.error = null
        tilPassword.error = null
        tilConfirm.error = null

        if (nama.isEmpty()) {
            tilNama.error = "Nama wajib diisi"
            return false
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.error = "Email tidak valid"
            return false
        }

        if (pass.length < 6) {
            tilPassword.error = "Password minimal 6 karakter"
            return false
        }

        if (pass != confirm) {
            tilConfirm.error = "Password tidak sama"
            return false
        }

        if (rgGender.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Pilih jenis kelamin", Toast.LENGTH_SHORT).show()
            return false
        }

        val hobbyCount = listOf(cbMusic, cbSport, cbGame, cbReading).count { it.isChecked }

        if (hobbyCount < 3) {
            Toast.makeText(this, "Pilih minimal 3 hobi", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    private fun setupSubmit() {
        btnSubmit.setOnClickListener {
            if (validateForm()) {
                AlertDialog.Builder(this)
                    .setTitle("Konfirmasi")
                    .setMessage("Apakah data sudah benar?")
                    .setPositiveButton("Ya") { _, _ ->
                        Toast.makeText(this, "Registrasi berhasil!", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            }
        }
    }

    private fun setupLongPress() {
        btnSubmit.setOnLongClickListener {
            Toast.makeText(this, "Long Press: Reset Form", Toast.LENGTH_SHORT).show()

            etNama.text?.clear()
            etEmail.text?.clear()
            etPassword.text?.clear()
            etConfirm.text?.clear()

            rgGender.clearCheck()

            cbMusic.isChecked = false
            cbSport.isChecked = false
            cbGame.isChecked = false
            cbReading.isChecked = false

            true
        }
    }

    private fun setupValidation() {
        etEmail.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val email = etEmail.text.toString()
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    tilEmail.error = "Format email salah"
                } else {
                    tilEmail.error = null
                }
            }
        }
    }
}